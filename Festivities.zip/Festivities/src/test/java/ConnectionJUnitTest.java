/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author ADMINM
 */
public class ConnectionJUnitTest {
    
    private static void Conectar() {    
    try{
//        String connectionUrl = "jdbc:sqlserver://localhost:1433;" +
//            "databaseName=pubs;user=sa; password=adminadmin;";    
        String connectionUrl = "jdbc:sqlserver://localhost\\TOSHIBA\\SQLEXPRESS:1434;databaseName=Festivities;user=sa; password=a;";
        // Declaramos los sioguientes objetos
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        //Establecemos la conexión
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        con = DriverManager.getConnection(connectionUrl);
        // Create and execute an SQL statement that returns some data.
        String SQL = "SELECT * FROM Festivity";
        stmt = con.createStatement();
        rs = stmt.executeQuery(SQL);
    }         
    catch (Exception e)
    {
        e.printStackTrace();
    }
 
}
    
    public static void main(String[] args) {
        Conectar();
    }
    
    
    public ConnectionJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
