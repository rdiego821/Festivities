package com.diego.festivities.controller;

/**
 *
 * @author diego
 */

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.diego.festivities.form.Festivity;
import com.diego.festivities.service.IFestivityService;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.core.MediaType;
import org.springframework.transaction.annotation.Transactional;

@Controller
public class FestivityController {
    @Autowired
    private IFestivityService festivityService;
    
    @RequestMapping("/index")
    public String listFestivity(Map<String, Object> map) {
        map.put("festivity", new Festivity());
        map.put("festivityList", festivityService.listFestivity());
        return "festivity";
    }
    
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @POST
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Transactional
    public String addFestivity(@ModelAttribute("festivity")
    Festivity festivity, BindingResult result) {
            festivityService.addFestivity(festivity);
            return "redirect:/index";
    }

    @RequestMapping("/delete/{festivityId}")
    public String removeFestivity(@PathVariable("festivityId")
    Integer festivityId) {
            festivityService.removeFestivity(festivityId);
            return "redirect:/index";
    }
}