
package com.diego.festivities.dao;

/**
 *
 * @author diego
 */

import java.util.List;
import com.diego.festivities.form.Festivity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class FestivityDAOImpl implements IFestivityDAO {
    @Autowired
    private SessionFactory sessionFactory;

    public void addFestivity(Festivity contact) {
        sessionFactory.getCurrentSession().save(contact);
    }
    
    public List<Festivity> listFestivity() {
        return sessionFactory.getCurrentSession().createQuery("from Festivity")
        .list();
    }
    
    public void removeFestivity(Integer id) {
        Festivity festivity = (Festivity) sessionFactory.getCurrentSession().load(
            Festivity.class, id);
        if (null != festivity) {
            sessionFactory.getCurrentSession().delete(festivity);
        }
    }
}
