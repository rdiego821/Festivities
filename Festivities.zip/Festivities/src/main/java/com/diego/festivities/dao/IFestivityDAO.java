package com.diego.festivities.dao;
/**
 *
 * @author diego
 */
import com.diego.festivities.form.Festivity;
import java.util.List;

public interface IFestivityDAO {
    public void addFestivity(Festivity festivity);
    public List<Festivity> listFestivity();
    public void removeFestivity(Integer id);
}
