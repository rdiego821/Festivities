package com.diego.festivities.service;

/**
 *
 * @author diego
 */

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.diego.festivities.dao.IFestivityDAO;
import com.diego.festivities.form.Festivity;

@Service
public class FestivityServiceImpl implements IFestivityService {
    @Autowired
    private IFestivityDAO festivityDAO;
    
    @Transactional
    public void addFestivity(Festivity festivity) {
        festivityDAO.addFestivity(festivity);
    }
    
    @Transactional
    public List<Festivity> listFestivity() {
         return festivityDAO.listFestivity();
    }

    @Transactional
    public void removeFestivity(Integer id) {
        festivityDAO.removeFestivity(id);
    }
}