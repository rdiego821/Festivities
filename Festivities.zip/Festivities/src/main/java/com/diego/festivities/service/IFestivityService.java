package com.diego.festivities.service;

/**
 *
 * @author diego
 */

import java.util.List;
import com.diego.festivities.form.Festivity;

public interface IFestivityService {
    public void addFestivity(Festivity festivity);
    public List<Festivity> listFestivity();
    public void removeFestivity(Integer id);
}
