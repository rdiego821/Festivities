<%@taglib uri="http://www.springframework.org/tags" prefix="spring"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Festivities 222 </title>
        <link rel="stylesheet" type="text/css" href="/css/festivity.css"/> 
    </head>
    <body>
        
        <h2>Festivities</h2>
         <form method="post" action="add">
        <table>
        <tr>
            <td><label>Name:</label></td>
        <td><input id="name" /></td> 
        </tr>
        <tr>
        <td><label>Place:</label></td>
        <td><input id="place" /></td>
        </tr>
        <tr>
        <td><label>Start Date:</label></td>
        <td><input id="stDate" type="date"/></td>
        </tr>
        <tr>
        <td><label>End Date:</label></td>
        <td><input id="endDate" type="date"/></td>
        </tr>
        <tr>
       
        <td colspan="2">
         <br>        
        <input type="submit" value="Add Festivity"/>
        </td>
        </tr>
       </table> 
       </form>
    </body>
</html>
